## ----load_packages, message=FALSE---------------------------------------------
library(here)
library(flextable)
library(data.table)
library(readxl)
library(SurveyTranslator)


## ----load_data----------------------------------------------------------------
items_data <- 
  data.table(read_xlsx(here("zdata/Translation data MENTOR.xlsx")))[
  grepl("ACE", Instrument)
]


## ----prepare_TranslationItems_object------------------------------------------
items <- prep_TranslationItems(
  data = items_data,
  examples = here("zdata/Sample surveys translation.xlsx"),
  source_language = "English",
  target_language = "Norwegian",
  domain = "Youth mental health",
  batch_vars = c("Instrument", "Topic")
)


## ----results='asis'-----------------------------------------------------------
cat(default_guidelines())


## -----------------------------------------------------------------------------
my_guidelines =
  '"Age-Appropriate Language: Use terminology and phrasing that are easily understandable and appropriate for adolescents aged 13–18.",
"Consistency with Research and Practice: Ensure that the language is consistent with terminology typically used in youth mental health research and clinical practice in the target country and language.",
"Natural Phrasing: Do not translate idioms, common expressions, or culturally specific phrases literally. Instead, use equivalent expressions that sound natural and familiar to youth in the target language.",
"Preserve Psychological Meaning: Retain the intended meaning and nuance of each item, even if this requires rewording or restructuring. Clarity and conceptual equivalence are more important than literal translation.",
"Cultural Appropriateness: Ensure that all content is culturally relevant and sensitive. Avoid references or terms that may be confusing, inappropriate, or irrelevant in the local context.",
"Alignment with Existing Translations: Where applicable, align terminology with existing validated translations of similar mental health instruments used in the target language.",
"Translator Notes: If a direct translation is not feasible or if you had to make interpretive decisions, please include a brief note explaining your choices."
'


## ----eval=FALSE---------------------------------------------------------------
# items <- prep_TranslationItems(
#   data = items_data,
#   examples = here("zdata/Sample surveys translation.xlsx"),
#   source_language = "English",
#   target_language = "Norwegian",
#   domain = "Youth mental health",
#   guidelines = my_guidelines,
#   batch_vars = c("Instrument", "Topic")
# )


## ----translation--------------------------------------------------------------
translated_items <- translate_survey(items, llm_model =  "gemini-2.0-flash-lite")


## -----------------------------------------------------------------------------
flextable(head(translated_items)[, Text := NULL])


## ----prepare_back_translation-------------------------------------------------
data_back_translation <- translated_items[
  , .(Instrument, Topic, translated_item, Type, Instruction, Response)
][, .(Text = translated_item, Instrument, Topic, Type, Instruction, Response)]

items_back_translation <- prep_TranslationItems(
  data = data_back_translation,
  examples = here("zdata/Sample surveys translation.xlsx"),
  reverse_transl = TRUE,
  source_language = "Norwegian",
  target_language = "English",
  domain = "Youth mental health",
  batch_vars = c("Instrument", "Topic")
)


## ----back_translation---------------------------------------------------------
back_translated_items <- translate_survey(items_back_translation)

flextable(head(back_translated_items)[, Text := NULL])


## ----evaluate_translations----------------------------------------------------
evaluation <- eval_translations(translated_items, back_translated_items)


## -----------------------------------------------------------------------------
n = nrow(evaluation)
n_not_OK = nrow(evaluation[evaluation != "OK"])
n_OK = n-n_not_OK


## -----------------------------------------------------------------------------
flextable(head(evaluation[evaluation != "OK"]))


## ----results='asis'-----------------------------------------------------------
cat(default_backtrans_guidelines())


## ----evaluation2--------------------------------------------------------------
back_trans_guidelines = 
'
You are an expert linguistic evaluator specializing in survey translation quality.
Your task is to evaluate the semantic equivalence between original survey statements and their back-translated versions.
Do not be too strict in the evaluation. Not all nuances can be transported back and forth between languages.
'
evaluation <- 
  eval_translations(
  translated_items,
  back_translated_items,
  guidelines = back_trans_guidelines)

n = nrow(evaluation)
n_not_OK = nrow(evaluation[evaluation != "OK"])
n_OK = n-n_not_OK


## ----eval=FALSE---------------------------------------------------------------
# writexl::write_xlsx(evaluation, path = here("translation_evaluation.xlsx"))


## ----eval=FALSE---------------------------------------------------------------
# library(flextable)
# library(officer)
# 
# ft <- flextable(evaluation) |>
#   width(j = "original",     width = 1.5) |>
#   width(j = "translation", width = 1.5) |>
#   width(j = "back_translation", width = 1.5) |>
#   width(j = "evaluation", width = 1.5) |>
#   set_table_properties(layout = "fixed", width = 1)
# doc <- read_docx() |>
#   body_add_flextable(ft)
# print(doc, target = here("translated_items.docx"))

